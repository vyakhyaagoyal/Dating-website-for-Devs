import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Heart, Code2, Sparkles } from 'lucide-react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AuthPage from './pages/AuthPage';
import { useAuthStore } from './store/authStore';

function App() {
  const { user, loading } = useAuthStore();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin text-purple-600">
          <Code2 size={40} />
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <Routes>
          <Route path="/" element={user ? <Home /> : <AuthPage />} />
        </Routes>
        
        {/* Fun Easter Egg */}
        <div 
          className="fixed bottom-4 right-4 cursor-pointer group"
          onClick={() => alert('You found a feature! 🎉\nJust like in programming, some of the best things in life are unexpected. Keep exploring!')}
        >
          <div className="relative">
            <Heart className="w-6 h-6 text-pink-500 transition-transform group-hover:scale-110" />
            <Sparkles className="w-4 h-4 text-yellow-400 absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;