import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Code2, LogOut, User } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

const Navbar = () => {
  const { user, signOut } = useAuthStore();

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-pink-500" />
              <Code2 className="h-8 w-8 text-purple-600" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                DevMatch
              </span>
            </Link>
          </div>

          {user && (
            <div className="flex items-center space-x-4">
              <Link
                to="/profile"
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <User className="h-6 w-6 text-gray-600" />
              </Link>
              <button
                onClick={() => signOut()}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <LogOut className="h-6 w-6 text-gray-600" />
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}

export default Navbar;