export type Profile = {
  id: string;
  username: string;
  avatar_url?: string;
  bio: string;
  preferred_language: string;
  debug_peeve: string;
  github_url?: string;
  tech_stack: string[];
  status: string;
  created_at: string;
};

export type Message = {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  created_at: string;
};

export type Match = {
  id: string;
  user1_id: string;
  user2_id: string;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
};