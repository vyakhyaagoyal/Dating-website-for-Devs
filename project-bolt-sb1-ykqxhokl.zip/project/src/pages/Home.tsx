import React, { useEffect, useState } from 'react';
import { Heart, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '../lib/supabase';
import type { Profile } from '../types/supabase';

const Home = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [acceptedProfiles, setAcceptedProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*');

      if (error) throw error;
      if (data) setProfiles(data);
    } catch (error) {
      console.error('Error fetching profiles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = (profile: Profile) => {
    setAcceptedProfiles([...acceptedProfiles, profile]);
    setProfiles(profiles.filter(p => p.id !== profile.id));
  };

  const floatingBubbleVariants = {
    initial: { scale: 0, y: 0 },
    animate: { 
      scale: 1,
      y: [0, -100, -200],
      opacity: [1, 1, 0],
      transition: { 
        duration: 2,
        ease: "easeOut"
      }
    },
    exit: { opacity: 0 }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin text-purple-600">
          <div className="h-12 w-12 border-4 border-t-purple-600 border-gray-200 rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <AnimatePresence>
        {acceptedProfiles.map((profile) => (
          <motion.div
            key={`accepted-${profile.id}`}
            variants={floatingBubbleVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="fixed pointer-events-none"
            style={{
              left: `${Math.random() * 80 + 10}%`,
              bottom: '20%'
            }}
          >
            <div className="bg-purple-100 rounded-full p-4">
              <img
                src={profile.avatar_url || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${profile.username}`}
                alt={profile.username}
                className="w-12 h-12 rounded-full"
              />
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {profiles.map((profile) => (
          <motion.div
            key={profile.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white rounded-xl shadow-lg overflow-hidden"
          >
            <div className="relative">
              <img
                src={profile.avatar_url || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${profile.username}`}
                alt={profile.username}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-4 right-4 bg-purple-600 text-white px-3 py-1 rounded-full text-sm">
                {profile.preferred_language} Developer
              </div>
            </div>

            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">{profile.username}</h3>
                <div className="flex space-x-2">
                  {profile.tech_stack?.map((tech, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <p className="text-gray-600 mb-4">{profile.bio || "No bio yet"}</p>

              <div className="border-t pt-4">
                <div className="flex justify-between">
                  <button
                    onClick={() => handleAccept(profile)}
                    className="flex items-center space-x-1 text-pink-600 hover:text-pink-700 transition-colors"
                  >
                    <Heart className="h-5 w-5" />
                    <span>Accept Match</span>
                  </button>
                  <button className="flex items-center space-x-1 text-purple-600 hover:text-purple-700 transition-colors">
                    <MessageSquare className="h-5 w-5" />
                    <span>Message</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Home;